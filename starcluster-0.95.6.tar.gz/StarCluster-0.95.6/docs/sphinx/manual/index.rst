.. StarCluster documentation master file, created by
   sphinx-quickstart on Mon Mar  1 13:47:45 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. _starcluster-user-manual:

StarCluster User Manual
=======================

Contents:

.. toctree::
   :maxdepth: 3

   configuration
   volumes
   launch
   runcommands
   putget
   getting_started
   create_new_ami
   list_public_amis
   plugins
   addremovenode
   load_balancer
   shell_completion
